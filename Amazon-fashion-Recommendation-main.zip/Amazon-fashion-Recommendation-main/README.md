# amazon-recommendation
content based recommendation system for appreals

Dataset in JSON formate can be downloaded from here:
https://indianinstituteofscience-my.sharepoint.com/:u:/g/personal/jaydeeps_iisc_ac_in/EXdeW7cuRxBFvW_VEGSAqtcBReRsX6kxllL4U7egJqtvsw?e=l3WmEC
